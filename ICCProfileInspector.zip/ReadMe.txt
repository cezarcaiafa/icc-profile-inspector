ICC Profile Inspector version 2.4.0 ReadMe file
Last Update: December 6 2022 (bug fix)
------------------------------------------------------------------

ICC Profile Inspector is a free software to view ICC profiles under Microsoft 
Windows operating system.  It displays the ICC header information, the ICC tag
table, and data in each tag. The tool is very useful for developing ICC tools 
and ICC profiles. It is aimed for checking tag data. Although it checks ICC 
profile's basic data structure, it was not designed to validate ICC profiles. 
The author accepts no liability for its behaviour.

System requirements:
  1) A PC runs under Windows 95 or later versions;
  2) Color monitor with at least 256 display colors;
  3) 10 Megabytes of free disk space.

Instalation:
  1) Download ICCProfileInspector.zip and unzip it, or
  2) Download ICCProfileInspector_setup.zip, unzip it, and click setup.exe
     to install it.

There are two methods to view an ICC profile:
1) a. Launch ICC Profile Inspector (or double-click ICCViewer.exe); and 
   b. Click Browse... button in the dialog box and then select an ICC profile. 
2) a. Move the mouse pointer to an ICC profile and then push left-mouse down to
      select the ICC profile; 
   b. Keep the mouse pointer down and move the file to drop on the ICC Profile
      Inspector icon; and
   c. Release the mouse button. 

Thank you for using ICC Profile Inspector! Any comments and suggestions are 
welcomed. please contact me via email ICCviewer@hotmail.com.

Huan (Huanzhao) Zeng